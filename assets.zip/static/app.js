"use strict";
const $ = (s, root = document) => root.querySelector(s);
const $$ = (s, root = document) => [...root.querySelectorAll(s)];
const escapeHTML = (v) => String(v ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const nf = new Intl.NumberFormat("pt-BR", {maximumFractionDigits:2});
const exact = v => nf.format(v || 0);
function compact(v) {
  const a = Math.abs(v || 0);
  return a >= 1e6 ? `${nf.format(v / 1e6)} kk` : a >= 1e3 ? `${nf.format(v / 1e3)} k` : exact(v);
}
function duration(v, seconds = false) {
  const h = Math.floor(v / 3600), m = Math.floor(v % 3600 / 60), s = Math.floor(v % 60);
  return `${h ? h + "h " : ""}${String(m).padStart(h ? 2 : 1,"0")}min${seconds ? " " + String(s).padStart(2,"0") + "s" : ""}`;
}
function dayLabel(s, year=false) { const [y,m,d] = s.slice(0,10).split("-"); return `${d}/${m}${year ? "/" + y : ""}`; }
function today() {const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;}
const paths = {
  dashboard:'<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  history:'<path d="M3 11a9 9 0 1 1 2.7 7M3 4v7h7M12 7v5l3 2"/>',
  price:'<path d="m3 12 9 9 9-9-9-9H3v9Z"/><circle cx="7.5" cy="7.5" r="1"/>',
  database:'<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 4 16 4 16 0V5M4 12c0 4 16 4 16 0"/>',
  plus:'<path d="M12 5v14M5 12h14"/>', calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4M17 3v4M3 11h18"/>',
  close:'<path d="m6 6 12 12M6 18 18 6"/>', arrow:'<path d="M5 12h14m-5-5 5 5-5 5"/>',
  clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', trend:'<path d="m3 17 6-6 4 4 8-10m-6 0h6v6"/>',
  wallet:'<rect x="3" y="5" width="18" height="15" rx="2"/><path d="M3 8h18m-5 5h5v4h-5z"/>',
  box:'<path d="m12 3 9 5v9l-9 5-9-5V8l9-5Zm0 9 9-4M12 12 3 8m9 4v10M7 5l10 6"/>',
  warning:'<path d="m12 3 10 18H2L12 3Zm0 6v5m0 3h.01"/>', search:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
  upload:'<path d="M12 16V3m-5 5 5-5 5 5M4 16v5h16v-5"/>', trash:'<path d="M3 6h18M8 6V3h8v3M5 6l1 15h12l1-15M10 10v7m4-7v7"/>',
  edit:'<path d="m15 4 5 5M4 20l5-1L21 7l-5-5L4 14v6Z"/>', check:'<path d="m5 12 4 4L19 6"/>'
};
function icon(name) { return `<svg class="icon" viewBox="0 0 24 24" aria-hidden="true">${paths[name] || paths.box}</svg>`; }
const imageKey=name=>battleKey(name).replace(/[^a-z0-9]/g,"");
function sprite(name, pokemon=false, originalName=name) {
  const custom=state.customImages?.[imageKey(originalName)];
  if(imageKey(name)==="alphaursaluna") name="Mystery Dungeon Alpha Ursaluna";
  const note=(name.startsWith("Mystery Dungeon ")||name.startsWith("Boss Fight - ")||name==="Lavender's Curse"||name.startsWith("Nightmare Terror - ")||name.startsWith("Nightmare Hunt - "))?"Imagem do local na Wiki PXG":name==="Darkrai Minion"?"Sprite de Darkrai":name==="Rainbow Totem"?"Sprite original enviado pelo usuário":"Imagem do Pokémon";
  return `<span class="sprite ${(name.startsWith("Mystery Dungeon ")||name.startsWith("Boss Fight - ")||name==="Lavender's Curse"||name.startsWith("Nightmare Terror - ")||name.startsWith("Nightmare Hunt - "))?"dungeon-sprite":pokemon?"pokemon-sprite":""}" title="${escapeHTML(note)}"><span class="sprite-fallback" aria-hidden="true">?</span><img src="${custom?escapeHTML(custom):'/api/sprite?'+new URLSearchParams({name,lookup:"8"})}" alt="" loading="lazy" decoding="async" onload="this.parentElement.classList.add('loaded')" onerror="this.hidden=true"></span>`;
}
function itemIdentity(name, detail="", pokemon=false, imageName=name) {
  return `<div class="item-identity">${sprite(imageName,pokemon,name)}<div class="identity-text"><span>${escapeHTML(name)}</span>${detail}</div></div>`;
}
function hydrateIcons() { $$('[data-icon]').forEach(e => {e.innerHTML = icon(e.dataset.icon);}); }
const categories={hunt:"Hunt",terror:"Terror",mystery_dungeon:"Mystery Dungeon",mixed:"Mista"};
const categoryPages={hunts:"hunt",terrors:"terror",dungeons:"mystery_dungeon"};
function categoryRecords(){return state.hunts.filter(h=>!categoryPages[state.page]||(h.category||"hunt")===categoryPages[state.page]);}
function loadBattlePins(){try{const pins=JSON.parse(localStorage.getItem("huntlog-battle-pins")||"[]");return new Set(Array.isArray(pins)?pins.filter(p=>typeof p==="string"):[]);}catch{return new Set();}}
const battleKey=name=>name.normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().trim();
const state = {page:"dashboard", hunts:[], stats:{}, locations:[], prices:[], draft:null, duplicate:false, filter:{}, search:"", priceSearch:"", priceZero:false, customImages:{}, battleTab:"normal", battleSearch:{normal:"",rare:"",dungeon:"",boss:""}, battlePins:loadBattlePins(), pendingDelete:null, request:0, backupInfo:null, restoreBackup:null, restoreSummary:null, restoreName:"", restoreGeneration:0};
let toastTimer;
function toast(text, error=false) {const e=$("#toast"); e.textContent=text;e.hidden=false;e.classList.toggle("error",error);clearTimeout(toastTimer);toastTimer=setTimeout(()=>e.hidden=true,4500);}
async function api(path, body) {
  const response = await fetch(path, body === undefined ? {} : {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Não foi possível concluir. Tente novamente.");
  return data;
}
async function refresh() {
  state.customImages=await api("/api/images");
  const request = ++state.request;
  const data = await api("/api/hunts?" + new URLSearchParams(state.filter));
  if (request !== state.request) return;
  Object.assign(state, data);
  const selected = $("#location-filter").value;
  $("#location-filter").innerHTML = '<option value="">Todos os locais</option>' + data.locations.map(l=>`<option value="${escapeHTML(l)}">${escapeHTML(l)}</option>`).join("");
  $("#location-filter").value=selected;
  $("#history-count").textContent=state.stats.count;
  state.profile=await api("/api/profile");renderProfile();
  const dates=state.stats.daily;
  $("#period-description").textContent=dates.length ? `${dayLabel(dates[0].date,true)} — ${dayLabel(dates.at(-1).date,true)} · ${state.stats.count} ${state.stats.count===1 ? "hunt" : "hunts"}` : "Nenhuma hunt no período";
  render();
}
async function changePage(page) {
  state.page = ["dashboard","history","prices","backup","hunts","terrors","dungeons","profession"].includes(page) ? page : "dashboard";
  const titles={profession:["Profissão","Recursos coletados pelos seus personagens."],hunts:["Hunts","Suas sessões de hunt e seus resultados."],terrors:["Terrors","Suas sessões de Terror e seus resultados."],dungeons:["Mystery Dungeons","Suas Mystery Dungeons e seus resultados."],dashboard:["Visão geral","Acompanhe seu lucro e faça seu tempo render."],history:["Histórico de hunts","Cada sessão, seus itens e o resultado do seu tempo."],prices:["Tabela de preços","Seus valores de referência para as próximas hunts."],backup:["Backup e restauração","Leve seu histórico e seus preços com você."]};
  $("#page-title").textContent=titles[state.page][0];$("#page-subtitle").textContent=titles[state.page][1];$("#breadcrumb").textContent=titles[state.page][0];
  $$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===state.page));
  $("#filters").hidden=["prices","backup"].includes(state.page);
  if(state.page==="prices") state.prices=await api("/api/prices");
  if(state.page==="backup") state.backupInfo=await api("/api/backup/info");
  render();
}
function render() {
  if(state.page==="profession") renderProfession();
  else if(state.page==="prices") renderPrices();
  else if((state.page==="history"||categoryPages[state.page])) renderHistory();
  else if(state.page==="backup") renderBackup();
  else renderDashboard();
}
function emptyState() {return `<div class="empty">${icon("box")}<h2>Seu próximo resultado começa aqui.</h2><p>Importe o JSON de uma hunt para acompanhar seu lucro.</p><button class="button primary" data-action="import">${icon("plus")}Registrar hunt</button></div>`;}
function metric(label,value,note,symbol,featured=false) {return `<div class="metric ${featured?"featured":""}"><div class="metric-label">${label}${icon(symbol)}</div><div class="metric-value">${value}</div><div class="metric-note">${note}</div></div>`;}
const signed = value => `${value>0?"+":""}${exact(value)}`;
function statusLabel(status) {return ({Paused:"Pausada",Running:"Em andamento",Stopped:"Encerrada",Finished:"Finalizada"})[status] || status || "Não informado";}
function profitComparison(data, aggregate=false) {
  const c=aggregate?data.comparison:{count:data.reported_profit==null?0:1,missing:data.reported_profit==null?1:0,reported:data.reported_profit,adjusted:data.profit,delta:data.profit-data.reported_profit,item_adjustment:data.raw-data.supplies-data.reported_profit,extras:data.extras};
  const adjusted=c.count?c.adjusted:data.profit;
  return `<section class="panel profit-comparison"><div class="panel-head"><div><h3>Lucro informado × ajustado</h3><p>${aggregate?"Comparação das hunts do período":"Valores desta sessão"}</p></div></div>
    <div class="compare-grid"><div><span>Informado pelo jogo</span><strong>${c.count?exact(c.reported):"Não informado"}</strong></div><div><span>Lucro ajustado</span><strong class="${adjusted<0?"negative":"positive"}">${exact(adjusted)}</strong></div><div><span>Diferença</span><strong class="${c.delta<0?"negative":"positive"}">${c.count?signed(c.delta):"—"}</strong></div></div>
    ${c.count?`<div class="compare-breakdown"><span>Ajustes nos itens <strong class="${c.item_adjustment<0?"negative":"positive"}">${signed(c.item_adjustment)}</strong></span><span>Gastos extras <strong class="${c.extras?"negative":""}">${signed(-c.extras)}</strong></span></div><p class="comparison-note">Informado + ajustes nos itens − gastos extras = ajustado. Os ajustes incluem preços, seleção de itens e diferenças do resumo.</p>`:'<p class="comparison-note">Este resumo não informa o lucro original. O lucro ajustado é calculado com os itens e os gastos extras.</p>'}
    ${aggregate&&c.missing?`<p class="comparison-note">${c.missing} hunt(s) sem lucro informado. ${c.count?"A comparação considera apenas as "+c.count+" com os dois valores; o painel mantém todas.":"Não é possível calcular a diferença."}</p>`:""}</section>`;
}
function renderBackup() {
  const info=state.backupInfo||{hunts:0,prices:0};
  $("#page-content").innerHTML=`<div class="backup-grid"><section class="panel backup-card"><span class="backup-symbol">${icon("database")}</span><h2>Guardar uma cópia</h2><p>Baixe todas as hunts, os Pokémon derrotados, os valores originais e ajustados e a tabela de preços.</p><div class="backup-counts"><strong>${info.hunts} ${info.hunts===1?"hunt":"hunts"}</strong><span>${info.prices} preços</span></div><a href="/api/backup" download class="button primary">${icon("database")}Baixar backup</a><p class="price-note">O arquivo JSON inclui todo o histórico, independentemente dos filtros. Guarde uma cópia fora desta pasta.</p></section>
    <section class="panel backup-card"><span class="backup-symbol">${icon("upload")}</span><h2>Restaurar uma cópia</h2><p>Selecione um backup do Huntlog para conferir o conteúdo antes de restaurar.</p><label class="drop-zone" for="backup-file">${icon("upload")}<span><strong>${escapeHTML(state.restoreName||"Selecionar backup JSON")}</strong><small>Arquivo exportado pelo Huntlog · até 50 MB</small></span></label><input type="file" id="backup-file" accept=".json,application/json" class="sr-only"><div id="restore-result"></div></section></div>
    ${info.recovery_available?'<div class="note-box recovery-note"><strong>Cópia antes da última restauração</strong><p>Para recuperar o estado anterior, baixe esta cópia e restaure o arquivo pelo formulário acima.</p><a class="button small" href="/api/backup/recovery" download>Baixar cópia anterior</a></div>':""}`;
  renderRestorePreview();
  $("#backup-file").addEventListener("change",async event=>{
    const file=event.target.files[0];if(!file)return;
    const generation=++state.restoreGeneration;state.restoreBackup=null;state.restoreSummary=null;state.restoreName=file.name;
    $("#restore-result").innerHTML='<p class="price-note">Conferindo o backup…</p>';
    try {
      if(file.size>50_000_000)throw new Error("Selecione um backup de até 50 MB.");
      let backup;try{backup=JSON.parse((await file.text()).replace(/^\uFEFF/,""));}catch{throw new Error("O arquivo não contém um JSON válido.");}
      const summary=await api("/api/restore/preview",{backup});
      if(generation!==state.restoreGeneration)return;
      state.restoreBackup=backup;state.restoreSummary=summary;
      if(state.page==="backup")renderBackup();
    }catch(e){if(state.page==="backup"&&generation===state.restoreGeneration)$("#restore-result").innerHTML=`<div class="form-error" role="alert">${escapeHTML(e.message)}</div>`;}
  });
}
function renderRestorePreview() {
  const s=state.restoreSummary;if(!s)return;
  $("#restore-result").innerHTML=`<div class="restore-preview"><h3>Conteúdo do backup</h3><dl><div><dt>Hunts</dt><dd>${s.hunts}</dd></div><div><dt>Preços</dt><dd>${s.prices}</dd></div><div><dt>Lucro ajustado</dt><dd>${exact(s.profit)}</dd></div><div><dt>Período</dt><dd>${s.start?dayLabel(s.start,true)+" a "+dayLabel(s.end,true):"Histórico vazio"}</dd></div></dl><p class="price-note">Criado em: ${escapeHTML(s.created_at||"data não informada")}</p></div>
    <div class="notice">${icon("warning")}<span>O backup substituirá todas as hunts e todos os preços atuais. Uma cópia dos dados atuais será guardada antes da restauração.</span></div>
    <label class="restore-confirm"><input type="checkbox" id="restore-confirm">Substituir meu histórico e minha tabela pelos dados deste backup.</label><button class="button danger" data-action="restore-backup" id="restore-submit" disabled>Substituir dados e restaurar</button>`;
  $("#restore-confirm").addEventListener("change",e=>{$("#restore-submit").disabled=!e.target.checked;});
}
function capturesPanel(records) {
  const groups=new Map();
  for(const record of records) for(const item of record.items||[]) {
    if(!item.is_capture||!item.included||!item.count)continue;
    const key=item.name.toLocaleLowerCase();
    const group=groups.get(key)||{name:item.name,count:0};group.count+=item.count;groups.set(key,group);
  }
  const rows=[...groups.values()],total=rows.reduce((n,r)=>n+r.count,0);
  if(!total)return "";
  return `<section class="panel captures-panel"><div class="panel-head"><div><p class="section-kicker">REGISTRO DE CAPTURAS</p><h3>Pokémon capturados</h3></div><span class="tag">${exact(total)} ${total===1?"captura":"capturas"}</span></div><div class="capture-list">${rows.map(r=>`<div class="capture-entry">${itemIdentity(r.name,"",true)}<strong>× ${exact(r.count)}</strong></div>`).join("")}</div><p class="encounter-foot">Pokémon na lista de loot representam capturas. O valor já está incluído no loot bruto.</p></section>`;
}
function defeatedPanel(data, aggregate=false) {
  const known=data.kills!=null, rows=aggregate?(data.defeated||[]):(data.enemies||[]).filter(e=>e.counted!==false);
  const tabs={normal:"Normais",rare:"Raros",dungeon:"Mystery Dungeons",boss:"Boss Fights"};
  const tabCount=(e,tab)=>{
    const group=e.battle_group||"pokemon";
    if(tab==="dungeon"||tab==="boss")return group===tab?e.count:0;
    if(group!=="pokemon")return 0;
    return tab==="rare"?(e.rare_count||0):e.count-(e.rare_count||0);
  };
  const totals=Object.fromEntries(Object.keys(tabs).map(tab=>[tab,rows.reduce((n,e)=>n+tabCount(e,tab),0)]));
  const battleRows=rows.map(e=>({...e,count:tabCount(e,state.battleTab),rare_count:state.battleTab==="rare"?(e.rare_count||0):0})).filter(e=>e.count>0&&battleKey(e.name).includes(battleKey(state.battleSearch[state.battleTab]||""))).sort((a,b)=>Number(state.battlePins.has(battleKey(b.name)))-Number(state.battlePins.has(battleKey(a.name)))||b.count-a.count);

  if(aggregate && known) return `<section class="panel encounter-panel"><div class="panel-head"><div><p class="section-kicker">REGISTRO DE BATALHA</p><h3>Pokémon derrotados</h3></div><div class="encounter-summary"><span><strong>${exact(data.kills)}</strong> no total</span><span><strong>${exact(data.rare_kills)}</strong> raros</span><span><strong>${exact(data.kills_per_hour)}</strong> / hora</span></div></div><div style="margin:0 24px 16px"><button class="button ghost small" id="edit-pokemon-images">Editar imagens</button></div><div class="battle-tabs" role="tablist" aria-label="Tipo de derrota">${Object.entries(tabs).map(([tab,label])=>`<button role="tab" data-battle-tab="${tab}" aria-selected="${state.battleTab===tab}" aria-controls="battle-results">${label} <span>${exact(totals[tab])}</span></button>`).join("")}</div><div class="battle-search"><label for="battle-search">Pesquisar em ${tabs[state.battleTab]}</label><input id="battle-search" type="search" placeholder="Digite o nome…" value="${escapeHTML(state.battleSearch[state.battleTab])}"><small>Use Editar imagem para trocar a foto ou Fixar para colocar o Pokémon no topo.</small></div><div id="battle-results" role="tabpanel" aria-label="${tabs[state.battleTab]}" class="encounter-grid">${battleRows.map(e=>`<div class="encounter-card ${state.battlePins.has(battleKey(e.name))?'is-pinned':''}">${sprite(e.image_name||e.name,true,e.name)}<div><strong class="encounter-name">${escapeHTML(e.name)}${state.battlePins.has(battleKey(e.name))?' <small class="pin-label">Fixado</small>':''}</strong><span class="encounter-caption">${e.battle_group==="boss"?"Boss Fight / Terror":e.battle_group==="dungeon"?"Boss de Mystery Dungeon":e.rare_count?"Encontro raro":"Registrado na hunt"}</span></div><div class="encounter-count"><strong>${exact(e.count)}</strong><span>${e.rare_count?`<span class="rare-dot"></span>${exact(e.rare_count)} raros`:"derrotados"}</span></div><div class="encounter-actions"><button type="button" class="text-button" data-edit-pokemon="${escapeHTML(e.name)}" aria-label="Editar imagem de ${escapeHTML(e.name)}">Editar imagem</button><button type="button" class="text-button" data-pin-pokemon="${escapeHTML(e.name)}" aria-pressed="${state.battlePins.has(battleKey(e.name))}" aria-label="${state.battlePins.has(battleKey(e.name))?'Desfixar':'Fixar'} ${escapeHTML(e.name)}">${state.battlePins.has(battleKey(e.name))?'Desfixar':'Fixar'}</button></div></div>`).join("")||'<p class="price-note">Nenhuma derrota encontrada nesta aba.</p>'}</div><p class="encounter-foot">${data.tracked_hunts} de ${data.count} hunts com contagem${data.tracked_hunts<data.count?" · média por hora apenas das hunts com contagem":""}</p></section>`;
  const subtitle=aggregate?`${data.tracked_hunts} de ${data.count} hunts com contagem no período`:"Contagem registrada nesta sessão";
  return `<section class="panel defeated-panel"><div class="panel-head"><div><h3>Pokémon derrotados</h3><p>${subtitle}</p></div></div>${known?`
    ${['terror','mystery_dungeon'].includes(data.category)?'<p class="price-note">Somente bosses reconhecidos no log entram nesta contagem. Outros Pokémon são desconsiderados.</p>':''}<div class="defeat-stats"><div><span>Total derrotado</span><strong>${exact(data.kills)}</strong></div><div><span>Raros</span><strong>${exact(data.rare_kills)}</strong></div><div><span>Derrotados por hora</span><strong>${exact(data.kills_per_hour)}</strong></div></div>
    <div class="table-wrap"><table><thead><tr><th>Pokémon</th><th class="amount">Quantidade</th></tr></thead><tbody>${rows.map(e=>`<tr class="${e.included===false?'disabled-row':''}"><td class="enemy-name">${itemIdentity(e.name, "", true, e.image_name||e.name)} ${e.rare||e.rare_count?`<span class="tag warning">${aggregate?exact(e.rare_count)+' raros':'Raro'}</span>`:''}${e.included===false?'<small>Ignorado na contagem</small>':''}</td><td class="amount">${exact(e.count)}</td></tr>`).join('')||'<tr><td colspan="2">Nenhum Pokémon derrotado registrado.</td></tr>'}</tbody></table></div>
    ${aggregate&&data.tracked_hunts<data.count?'<p class="price-note defeated-note">A média por hora considera somente as hunts com contagem disponível.</p>':''}`:'<p class="price-note defeated-note">Contagem não disponível. Reimporte o resumo completo para incluir os Pokémon derrotados.</p>'}</section>`;
}
function chart(days) {
  const groups = days.length<=31 ? days : Object.values(days.reduce((acc,d)=>{const key=d.date.slice(0,7);(acc[key]??={date:key+"-01",profit:0}).profit+=d.profit;return acc;},{}));
  const grouped=days.length>31, width=650, height=210, left=67, right=15, top=14, bottom=32;
  let lo=Math.min(0,...groups.map(d=>d.profit)), hi=Math.max(0,...groups.map(d=>d.profit));
  if(hi===lo)hi=1;
  const range=hi-lo; if(hi>0) hi+=range*.1; if(lo<0)lo-=range*.08;
  const y=v=>top+(hi-v)/(hi-lo)*(height-top-bottom), base=y(0), gap=(width-left-right)/groups.length;
  let svg=`<svg class="daily-chart" viewBox="0 0 ${width} ${height}" role="img" aria-label="Lucro ${grouped?"mensal":"diário"}: ${escapeHTML(groups.map(d=>dayLabel(d.date)+": "+exact(d.profit)).join("; "))}">`;
  for(let i=0;i<4;i++) {const v=lo+(hi-lo)*i/3, py=y(v);svg+=`<line x1="${left}" x2="${width-right}" y1="${py}" y2="${py}" stroke="#304046" stroke-dasharray="3 5"/><text x="${left-10}" y="${py+4}" text-anchor="end" fill="#8c9fa4" font-size="11">${compact(v)}</text>`;}
  if(lo<0)svg+=`<line x1="${left}" x2="${width-right}" y1="${base}" y2="${base}" stroke="#71878d"/>`;
  groups.forEach((d,i)=>{const cx=left+gap*(i+.5),bw=Math.max(2,Math.min(48,gap*.6));svg+=`<rect x="${cx-bw/2}" y="${d.profit>=0?y(d.profit):base}" width="${bw}" height="${Math.max(1,Math.abs(y(d.profit)-base))}" rx="4" fill="${d.profit>=0?"#79b9fa":"#ff9b9b"}"><title>${dayLabel(d.date,true)}: ${exact(d.profit)}</title></rect>`;
    if(i%Math.ceil(groups.length/7)===0)svg+=`<text x="${cx}" y="${height-8}" text-anchor="middle" fill="#9caeb2" font-size="11">${grouped ? d.date.slice(0,7).split("-").reverse().join("/") : dayLabel(d.date)}</text>`;
    if(groups.length===1)svg+=`<text x="${cx}" y="${y(d.profit)-8}" text-anchor="middle" fill="#b0d5ff" font-size="12">${compact(d.profit)}</text>`;
  }); return svg+"</svg>";
}
function huntOnly(h) {
  const value=h.profession_raw||0;
  return {...h,items:h.items.filter(i=>!i.profession),raw:h.raw-value,profit:h.profit-value,hourly:(h.profit-value)*3600/h.duration,reported_profit:null};
}
function professionRows(records) {
  const groups=new Map();
  for(const h of records)for(const i of h.items)if(i.included&&i.profession){const key=imageKey(i.name),row=groups.get(key)||{name:i.name,profession:i.profession,count:0,total:0};row.count+=i.count;row.total+=i.total;groups.set(key,row);}
  return [...groups.values()].sort((a,b)=>b.total-a.total||a.name.localeCompare(b.name));
}
function renderProfession() {
  const rows=professionRows(state.hunts),total=rows.reduce((n,i)=>n+i.total,0);
  $("#period-description").textContent=`${rows.length} recursos no período`;
  $("#page-content").innerHTML=`<div class="mini-metrics"><div class="mini-metric"><span>Valor dos recursos</span><strong>${exact(total)}</strong></div><div class="mini-metric"><span>Quantidade coletada</span><strong>${exact(rows.reduce((n,i)=>n+i.count,0))}</strong></div></div><p class="price-note">Valor bruto dos recursos reconhecidos no JSON, pelos preços salvos de cada sessão. Os custos da sessão permanecem na hunt. A visão geral inclui este valor uma única vez.</p><section class="panel"><div class="table-toolbar"><label class="field">Pesquisar recurso ou profissão<input id="profession-search" type="search" placeholder="Nome do recurso ou profissão"></label></div><div id="profession-table"></div></section>`;
  const draw=()=>{const q=$("#profession-search").value.toLowerCase(),filtered=rows.filter(i=>(i.name+' '+i.profession).toLowerCase().includes(q));$("#profession-table").innerHTML=filtered.length?`<div class="table-wrap"><table><thead><tr><th>Recurso</th><th>Profissão</th><th class="amount">Quantidade</th><th class="amount">Valor total</th></tr></thead><tbody>${filtered.map(i=>`<tr><td>${itemIdentity(i.name)}</td><td>${escapeHTML(i.profession)}</td><td class="amount">${exact(i.count)}</td><td class="amount">${exact(i.total)}</td></tr>`).join('')}</tbody></table></div>`:'<p class="price-note">Nenhum recurso de profissão encontrado neste período.</p>';};
  $("#profession-search").addEventListener('input',draw);draw();
}
function huntTable(hunts) {
  if(state.page==='hunts')hunts=hunts.map(huntOnly);
  if(!hunts.length)return '<div class="empty compact"><p>Nenhuma hunt encontrada.</p></div>';
  return `<div class="table-wrap"><table><thead><tr><th>Hunt / local</th><th>Data</th><th>Tempo</th><th class="amount">Derrotados</th><th class="amount">Informado</th><th class="amount">Ajustado</th><th class="amount">Por hora</th><th><span class="sr-only">Detalhes</span></th></tr></thead><tbody>${hunts.map(h=>`<tr><td><div class="hunt-cell">${sprite(h.terror_image||h.dungeon_image||h.hunt_image||(h.enemies||[]).filter(e=>e.included!==false).sort((a,b)=>b.count-a.count)[0]?.name||"Poké Ball", true)}<div>${escapeHTML(h.location || "Local não informado")}<small>${escapeHTML(h.player)} · ${categories[h.category||"hunt"]} · sessão ${escapeHTML(h.session_id)}${h.status?" · "+escapeHTML(statusLabel(h.status)):""}</small></div></div></td><td>${dayLabel(h.date,true)}<small>${h.started.slice(11,16)}</small></td><td title="${duration(h.duration,true)}">${duration(h.duration)}</td><td class="amount">${h.kills==null?'—':exact(h.kills)}${h.rare_kills?`<small>${exact(h.rare_kills)} raros</small>`:""}</td><td class="amount" title="${h.reported_profit==null?"Não informado":exact(h.reported_profit)}">${h.reported_profit==null?"—":compact(h.reported_profit)}</td><td class="amount ${h.profit>=0?"positive":"negative"}" title="${exact(h.profit)}">${compact(h.profit)}</td><td class="amount" title="${exact(h.hourly)}">${compact(h.hourly)}</td><td><button class="icon-button" data-action="detail" data-id="${h.id}" aria-label="Abrir hunt de ${dayLabel(h.date)} às ${h.started.slice(11,16)}">${icon("arrow")}</button></td></tr>`).join("")}</tbody></table></div>`;
}
function renderDashboard() {
  const s=state.stats;
  if(!s.count) {$("#page-content").innerHTML=emptyState();return;}
  const drops={};state.hunts.forEach(h=>h.items.filter(i=>i.kind==="drop"&&i.included).forEach(i=>drops[i.name]=(drops[i.name]||0)+i.total));
  const top=Object.entries(drops).filter(([,v])=>v>0).sort((a,b)=>b[1]-a[1]).slice(0,4);
  const best=[...s.daily].sort((a,b)=>b.profit-a.profit)[0];
  $("#page-content").innerHTML=`<div class="metrics">
    ${metric("Lucro ajustado",`<span class="${s.profit<0?"negative":""}" title="${exact(s.profit)}">${compact(s.profit)}</span>`,`${s.count} ${s.count===1?"hunt registrada":"hunts registradas"}`,"wallet",true)}
    ${metric("Lucro ajustado/h",compact(s.hourly),"Ponderado pelo tempo de hunt","trend")}
    ${metric("Tempo de hunt",duration(s.duration),`${s.active_days} ${s.active_days===1?"dia jogado":"dias jogados"}`,"clock")}
    ${metric("Média por dia",compact(s.daily_average),"Considera apenas os dias jogados","calendar")}
    </div><div class="flow-strip"><span>Loot bruto <strong>${compact(s.raw)}</strong></span><span class="math">−</span><span>Supplies e extras <strong>${compact(s.cost)}</strong></span><span class="math">=</span><span>Lucro <strong class="positive">${compact(s.profit)}</strong></span><span class="flow-note">${s.kills==null?"":`${exact(s.kills)} Pokémon derrotados · ${exact(s.rare_kills)} raros`}</span></div>
    ${defeatedPanel(s,true)}${capturesPanel(state.hunts)}
    <div class="grid-main"><section class="panel"><div class="panel-head"><div><h3>Resultado ${s.daily.length>31?"por mês":"por dia"}</h3><p>Lucro ajustado nas datas registradas</p></div><span class="legend">Lucro</span></div><div class="chart-wrap">${chart(s.daily)}</div><div class="chart-foot"><span>Melhor dia <strong>${dayLabel(best.date)} · ${compact(best.profit)}</strong></span><span>${s.active_days===1?"Mais hunts, mais contexto.":s.active_days+" dias no histórico"}</span></div></section>
    <section class="panel"><div class="panel-head"><div><h3>Destaques do loot</h3><p>Itens com maior valor acumulado</p></div>${icon("box")}</div><div class="loot-list">${top.map(([name,value])=>`<div class="loot-row"><div class="loot-text">${itemIdentity(name)}<strong>${compact(value)}</strong></div><div class="track"><span style="width:${Math.max(1,value/s.raw*100)}%"></span></div></div>`).join("")}</div><div class="loot-total">Participação no valor total dos drops</div></section></div>
    <section class="panel recent-panel"><div class="panel-head"><h3>Últimas hunts</h3><button class="text-button" data-action="history">Ver histórico ${icon("arrow")}</button></div>${huntTable(state.hunts.slice(0,4))}</section>
    ${s.zero_prices?`<div class="notice">${icon("warning")}<span><strong>${s.zero_prices} ${s.zero_prices===1?"item com preço zero":"itens com preço zero"}.</strong> Revise os valores para uma estimativa mais completa.</span><button class="text-button" data-action="history">Revisar hunts</button></div>`:""}`;
}
function renderHistory() {
  $("#period-description").textContent = `${categoryRecords().length} registros no período${categoryPages[state.page]?" · "+categories[categoryPages[state.page]]:" · todas as categorias"}`;
  $("#page-content").innerHTML=`${state.page==="hunts"?'<p class="price-note">Os recursos de profissão e seus valores estão na aba Profissão. Os gastos da sessão continuam descontados aqui.</p>':""}<section class="panel"><div class="table-toolbar"><div class="search"><span>${icon("search")}</span><label class="sr-only" for="hunt-search">Buscar hunts</label><input id="hunt-search" placeholder="Buscar local, personagem ou sessão" value="${escapeHTML(state.search)}"></div><span class="subtle">${categoryRecords().length} registros no período</span></div><div id="history-table"></div></section>`;
  renderHistoryRows();
  $("#hunt-search").addEventListener("input",e=>{state.search=e.target.value;renderHistoryRows();});
}
function renderHistoryRows() {const q=state.search.toLowerCase();$("#history-table").innerHTML=huntTable(categoryRecords().filter(h=>[h.location,h.player,h.session_id,h.date,h.server,h.pokemon].join(" ").toLowerCase().includes(q)));}
function renderPrices() {
  $("#page-content").innerHTML=`<p class="info-line">Ao salvar, escolha se os preços alterados valem somente para próximas hunts ou também para todo o histórico.</p><section class="panel"><div class="table-toolbar"><div class="search"><span>${icon("search")}</span><label class="sr-only" for="price-search">Buscar item</label><input id="price-search" placeholder="Buscar item…" value="${escapeHTML(state.priceSearch)}"></div><label><input type="checkbox" id="price-zero" ${state.priceZero?"checked":""}> Somente preço zero</label><div class="price-actions"><span class="subtle">${state.prices.length} itens</span><button class="button primary small" data-action="save-prices">${icon("check")}Salvar preços</button></div></div><div id="prices-table"></div></section><p class="price-note">Valores em unidades do jogo. Use 150000 para 150 k. Itens sem alteração continuam usando o preço de cada JSON. A tabela é única para esta instalação.</p>`;
  $("#price-zero").addEventListener("change",e=>{state.priceZero=e.target.checked;renderPriceRows();});
  renderPriceRows();
  $("#price-search").addEventListener("input",e=>{state.priceSearch=e.target.value;renderPriceRows();});
}
function renderPriceRows() {
  const filtered=state.prices.map((p,i)=>({...p,index:i})).filter(p=>p.name.toLowerCase().includes(state.priceSearch.toLowerCase())&&(!state.priceZero||p.price===0));
  $("#prices-table").innerHTML=filtered.length?`<div class="table-wrap"><table><thead><tr><th>Item</th><th>Categoria</th><th>Uso nas próximas hunts</th><th class="amount">Preço unitário</th></tr></thead><tbody>${filtered.map(p=>`<tr><td>${itemIdentity(p.name,p.price===0?'<small class="price-missing">Preço zero</small>':"")}</td><td><span class="tag ${p.kind==="supply"?"warning":""}">${p.is_capture?"Captura":p.kind==="drop"?"Drop":"Supply"}</span></td><td><span class="subtle">${p.custom?"Preço personalizado":"Preço do JSON"}</span></td><td class="amount"><input class="price-input" type="number" min="0" step="0.01" value="${p.price}" data-price-index="${p.index}" aria-label="Preço de ${escapeHTML(p.name)}"></td></tr>`).join("")}</tbody></table></div>`:'<div class="empty compact"><p>Nenhum item encontrado. Os itens aparecem ao salvar uma hunt.</p></div>';
  $$("[data-price-index]").forEach(e=>e.addEventListener("input",()=>{state.prices[Number(e.dataset.priceIndex)].price=e.valueAsNumber;}));
}
function openImport() {
  state.draft=null;state.duplicate=false;
  $("#import-title").textContent="Registrar hunt";
  $("#import-body").innerHTML=`<p class="muted">Cole o resumo exportado pelo jogo ou escolha um arquivo.</p><label class="drop-zone" for="json-file">${icon("upload")}<span><strong id="upload-title">Selecionar arquivo JSON</strong><small>.json ou .txt · até 5 MB</small></span></label><input type="file" id="json-file" accept=".json,.txt,application/json,text/plain" class="sr-only"><div class="or-line">ou cole o conteúdo</div><label class="sr-only" for="json-input">JSON do resumo da hunt</label><textarea id="json-input" class="json-input" spellcheck="false" placeholder='{ "Drops": [...], "Supplies": [...], "Session": {...} }'></textarea><div id="import-error" class="form-error" hidden></div><div class="modal-actions"><button class="text-button left" data-action="sample">Experimentar exemplo fictício</button><button class="button primary" data-action="preview">Revisar importação ${icon("arrow")}</button></div>`;
  $("#json-file").addEventListener("change",async e=>{const file=e.target.files[0];if(!file)return;if(file.size>5e6)return importError("Selecione um arquivo de até 5 MB.");try{$("#json-input").value=await file.text();$("#upload-title").textContent=file.name;$("#import-error").hidden=true;}catch{importError("Não consegui abrir o arquivo. Tente colar o conteúdo.");}});
  if(!$("#import-dialog").open)$("#import-dialog").showModal();
}
function importError(message) {const e=$("#import-error");if(e){e.textContent=message;e.hidden=false;}else toast(message,true);}
function recomputeDraft() {
  const d=state.draft;
  const key=n=>imageKey(n)||n.trim().toLowerCase(),rules=d.boss_rules||{terror:[],unique:[],dungeons:{}};
  const allowed=d.category==='terror'?rules.terror:(rules.dungeons[key(d.location||'')]||rules.unique);
  (d.enemies||[]).forEach(e=>{const n=key(e.name);e.image_name=['entei','raikou','suicune'].includes(n)&&!['terror','mixed'].includes(d.category)?'':(rules.images?.[n]||rules.dungeon_images?.[n]||'');});
  (d.enemies||[]).forEach(e=>e.counted=!['terror','mystery_dungeon'].includes(d.category)||allowed.includes(key(e.name))||(d.category==='terror'&&!!rules.images?.[key(e.name)]));
  (d.enemies||[]).forEach(e=>{if(['terroralakazam','terrorgengar','seishin','yurei'].includes(key(e.name)))e.counted=false;});
  for(const e of d.enemies||[]) {e.count=e.reported_count??e.count;e.ghost_excluded=0;}
  d.ghost_adjustment=null;
  if((d.enemies||[]).some(e=>key(e.name)==='bossgiantghost'&&e.included&&e.count>0)) {
    const costs={normal:1,hard:2,expert:4};
    const difficulties=Object.keys(costs).filter(t=>d.items.some(i=>i.kind==='drop'&&i.included&&i.count>0&&key(i.name)==='ghostlylootbag'+t));
    const tags=d.items.filter(i=>i.kind==='supply'&&i.included&&['spelltag','spelltags'].includes(key(i.name))).reduce((n,i)=>n+i.count,0);
    if(difficulties.length===1&&tags>0&&tags%costs[difficulties[0]]===0){
      const difficulty=difficulties[0],attempts=tags/costs[difficulty],limits={gastly:4*attempts,haunter:2*attempts,gengar:attempts,shinygengar:attempts};let excluded=0;
      for(const e of d.enemies){const k=key(e.name);if(e.included&&k in limits){const n=Math.min(e.count,limits[k]);e.count-=n;e.ghost_excluded=n;limits[k]-=n;excluded+=n;}}
      d.ghost_adjustment={difficulty,attempts,spell_tags:tags,excluded};
    }
  }
  if(d.enemies){const counted=d.enemies.filter(e=>e.included&&e.counted);d.kills=counted.reduce((n,e)=>n+e.count,0);d.rare_kills=counted.filter(e=>e.rare).reduce((n,e)=>n+e.count,0);d.kills_per_hour=d.kills*3600/d.duration;}
  d.items.forEach(i=>i.total=Math.round(i.price*i.count*100)/100);
  d.raw=d.items.filter(i=>i.kind==="drop"&&i.included).reduce((n,i)=>n+i.total,0);
  d.supplies=d.items.filter(i=>i.kind==="supply"&&i.included).reduce((n,i)=>n+i.total,0);
  d.profit=d.raw-d.supplies-d.extras;
  d.zero_prices=d.items.filter(i=>i.included&&i.price===0&&i.count>0).length;
}
function review(record,duplicate=false,editing=false,previous=null) {
  state.draft=structuredClone(record);state.duplicate=duplicate;
  const d=state.draft;if(!duplicate&&!editing)d.category=d.suggested_category||"";
  $("#import-title").textContent=editing?"Editar hunt":"Revisar hunt";
  $("#import-body").innerHTML=`<div class="review-meta"><strong>${escapeHTML(d.player)}</strong><span>${dayLabel(d.date,true)} às ${d.started.slice(11,16)}</span><span>${duration(d.duration,true)}</span><span>Sessão ${escapeHTML(d.session_id)}</span>${d.status?`<span class="tag">${escapeHTML(statusLabel(d.status))}</span>`:""}</div>
    ${duplicate&&!editing?'<div class="notice" style="margin:0 0 20px">'+icon("history")+'<span>Esta sessão já está salva. Os preços anteriores foram preservados; as quantidades e os Pokémon derrotados serão atualizados pelo resumo.</span></div>':""}
    ${duplicate&&!editing&&previous?`<div class="update-summary"><strong>Atualização da mesma sessão</strong><span>Tempo: ${duration(previous.duration,true)} → ${duration(d.duration,true)}</span><span>Derrotados: ${previous.kills==null?"—":exact(previous.kills)} → ${d.kills==null?"—":exact(d.kills)}</span><small>Personagem + início + ID coincidem. Este registro será atualizado, sem somar duas vezes.</small></div>`:""}
    <div class="fields"><label class="field full"><span>Categoria da atividade *</span><select data-field="category" required><option value="">Selecione Hunt, Terror, Mystery Dungeon ou Mista</option>${Object.entries(categories).map(([value,label])=>`<option value="${value}" ${d.category===value?"selected":""}>${label}</option>`).join("")}</select></label><label class="field"><span id="location-label">Local da hunt</span><input data-field="location" list="dungeon-options" placeholder="Identificado pelos Pokémon derrotados" value="${escapeHTML(d.location)}" maxlength="200"><datalist id="dungeon-options">${(d.dungeon_options||[]).map(name=>`<option value="${escapeHTML(name)}"></option>`).join("")}</datalist><small id="location-hint"></small><button type="button" class="text-button" id="detect-location">Usar identificação automática</button></label><label class="field"><span>Gastos extras</span><input data-field="extras" type="number" min="0" step="0.01" value="${d.extras}"><small>Somente custos que não estão nos supplies.</small></label></div>
    <div class="mini-metrics"><div class="mini-metric"><span>Loot bruto</span><strong id="draft-raw"></strong></div><div class="mini-metric"><span>Supplies + extras</span><strong id="draft-cost"></strong></div><div class="mini-metric"><span>Lucro ajustado</span><strong id="draft-profit" class="positive"></strong></div></div>
    <div id="draft-comparison"></div>
    <div class="section-heading"><h3>Itens e preços <span class="subtle">(${d.items.length})</span></h3></div><p class="price-note">${duplicate?"Preços preservados desta sessão. Alterações na tabela valem somente para novas hunts.":"Preços personalizados aplicados automaticamente. Os demais itens usam o preço do JSON."} Você pode ajustar um valor manualmente apenas nesta hunt.</p>
    <div class="review-table"><table><thead><tr><th>Usar</th><th>Item</th><th>Qtd.</th><th class="amount">Preço unitário</th><th class="amount">Total</th></tr></thead><tbody>${d.items.map((i,n)=>`<tr data-item-row="${n}" class="${i.included?"":"disabled-row"}"><td><input type="checkbox" data-include="${n}" ${i.included?"checked":""} aria-label="Incluir ${escapeHTML(i.name)}"></td><td class="item-name">${itemIdentity(i.name,`<small class="kind-label">${i.is_capture?"CAPTURA":i.kind==="drop"?"DROP":"SUPPLY"}</small>`)}</td><td>${exact(i.count)}</td><td class="amount"><input type="number" min="0" step="0.01" value="${i.price}" data-item-price="${n}" aria-label="Preço de ${escapeHTML(i.name)}"><small data-original-price="${n}"></small></td><td class="amount" data-item-total="${n}">${compact(i.total)}</td></tr>`).join("")}</tbody></table></div>
    <p class="price-note" id="draft-warning"></p><div id="draft-rare-selection"></div><div id="draft-defeated">${defeatedPanel(d)}</div><div id="draft-captures"></div><label class="field"><span>Observações</span><textarea data-field="notes" rows="2" maxlength="2000" placeholder="Como foi a hunt?">${escapeHTML(d.notes)}</textarea></label><div id="import-error" class="form-error" hidden></div>
    <div class="modal-actions">${!editing?'<button class="button ghost left" data-action="back-import">Voltar</button>':""}<button class="button close-dialog">Cancelar</button><button class="button primary" data-action="save-hunt">${icon("check")}${duplicate?"Atualizar hunt":"Salvar hunt"}</button></div>`;
  $$("[data-field]",$("#import-body")).forEach(e=>e.addEventListener("input",()=>{d[e.dataset.field]=e.dataset.field==="extras"?e.valueAsNumber:e.value;if(e.dataset.field==="location")d.location_source="manual";if(e.dataset.field==="category")updateLocation();updateReview();}));
  $("#detect-location").addEventListener("click",()=>{d.location_source="auto";updateLocation();updateReview();});
  updateLocation();
  $$("[data-item-price]").forEach(e=>e.addEventListener("input",()=>{const item=d.items[Number(e.dataset.itemPrice)];item.price=e.valueAsNumber;item.price_source="manual";updateReview();}));
  $$("[data-include]").forEach(e=>e.addEventListener("change",()=>{d.items[Number(e.dataset.include)].included=e.checked;updateReview();}));
  updateReview();if(!$("#import-dialog").open)$("#import-dialog").showModal();
}
function updateLocation() {
  const d=state.draft, dungeon=d.category==="mystery_dungeon";
  $("#dungeon-options").innerHTML=(dungeon?(d.dungeon_options||[]):d.category==="hunt"?(d.hunt_options||[]):[]).map(name=>`<option value="${escapeHTML(name)}"></option>`).join("");
  if(d.category==="terror")d.location_source="auto";
  $('[data-field="location"]').readOnly=d.category==="terror";
  const suggestion=d.location_suggestions?.[d.category||"hunt"]||"";
  if(d.location_source!=="manual") {d.location=suggestion;$('[data-field="location"]').value=suggestion;}
  $("#location-label").textContent=dungeon?"Mystery Dungeon":d.category==="mixed"?"Local / descrição da sessão":"Local da hunt";
  $("#location-hint").textContent=d.category==="mixed"?"Sessão com atividades variadas. Todos os Pokémon derrotados incluídos no log serão contabilizados.":d.category==="terror"?"Esta sessão será registrada como Terror.":d.location_source==="manual"?"Local definido por você. Pode usar a identificação automática abaixo.":suggestion?(dungeon?"Identificada pelo boss derrotado. Confira antes de salvar.":"Preenchido pelo Pokémon com mais derrotas."):(dungeon?"Não foi possível identificar uma única dungeon. Selecione ou digite o nome.":"Sem derrotas suficientes ou empate. Informe o local.");
}
function rareSelection(d) {
  const rows=(d.enemies||[]).map((e,index)=>({e,index})).filter(({e})=>e.rare);
  if(!rows.length)return '';
  return `<section class="panel"><div class="panel-head"><div><h3>Pokémon raros desta sessão</h3><p>Desmarque somente os que não devem contar. Loots e lucro não são alterados.</p></div></div><div class="table-wrap"><table><thead><tr><th>Incluir</th><th>Pokémon</th><th class="amount">Quantidade</th></tr></thead><tbody>${rows.map(({e,index})=>`<tr class="${e.included===false?'disabled-row':''}"><td><input type="checkbox" data-enemy-include="${index}" ${e.included!==false?'checked':''} aria-label="Incluir ${escapeHTML(e.name)} na contagem"></td><td>${itemIdentity(e.name,'',true,e.image_name||e.name)}</td><td class="amount">${exact(e.count)}</td></tr>`).join('')}</tbody></table></div></section>`;
}
function updateReview() {
  recomputeDraft();const d=state.draft;
  $("#draft-raw").textContent=exact(d.raw);$("#draft-cost").textContent=exact(d.supplies+d.extras);$("#draft-profit").textContent=exact(d.profit);$("#draft-profit").className=d.profit<0?"negative":"positive";
  d.items.forEach((i,n)=>{const e=$(`[data-item-total="${n}"]`);e.textContent=compact(i.total);e.title=exact(i.total);$(`[data-item-row="${n}"]`).classList.toggle("disabled-row",!i.included);});
  $("#draft-comparison").innerHTML=profitComparison(d);$("#draft-captures").innerHTML=capturesPanel([d]);
  d.items.forEach((item,n)=>{$(`[data-original-price="${n}"]`).textContent=item.reported_price!=null&&Math.abs(item.price-item.reported_price)>.009?"JSON: "+exact(item.reported_price):"";});
  const warnings=[];
  if((d.enemies||[]).some(e=>e.damage_inferred&&e.counted&&e.included))warnings.push("Alguns Terrores foram identificados pelo dano: conta-se uma participação por Terror, pois o dano não informa quantas vitórias ocorreram.");
  if(d.zero_prices)warnings.push(`${d.zero_prices} itens com preço zero. Revise os que têm custo ou valor de venda.`);
  if(d.reported_profit!==null&&Math.abs(d.profit-d.reported_profit)>.01)warnings.push(`Lucro no JSON: ${exact(d.reported_profit)}. A revisão usa os itens selecionados, seus preços e os gastos extras.`);
  if(['terror','mystery_dungeon'].includes(d.category))warnings.push('Nesta categoria contam somente bosses reconhecidos no log. Os outros Pokémon ficam fora das estatísticas.');
  $("#draft-rare-selection").innerHTML=rareSelection(d);
  $$("[data-enemy-include]",$("#draft-rare-selection")).forEach(input=>input.addEventListener("change",()=>{d.enemies[Number(input.dataset.enemyInclude)].included=input.checked;updateReview();}));
  $("#draft-defeated").innerHTML=defeatedPanel(d);
  $("#draft-warning").textContent=warnings.join(" ");
}
function openDetail(id) {
  let h=state.hunts.find(r=>r.id===id);if(!h)return;if(state.page==="hunts")h=huntOnly(h);
  $("#detail-body").innerHTML=`<div class="modal-head"><div><p class="eyebrow">SESSÃO ${escapeHTML(h.session_id)}</p><h2 id="detail-title">${escapeHTML(h.location||"Detalhes da hunt")}</h2></div><button class="icon-button close-dialog" aria-label="Fechar">${icon("close")}</button></div><div class="detail-meta">${[["Categoria",categories[h.category||"hunt"]],["Personagem",h.player],["Data",dayLabel(h.date,true)+" · "+h.started.slice(11,16)],["Tempo",duration(h.duration,true)],["Lucro ajustado/h",compact(h.hourly)],["Estado no jogo",statusLabel(h.status)]].map(([k,v])=>`<div><small>${k}</small><span>${escapeHTML(v)}</span></div>`).join("")}</div><div class="mini-metrics"><div class="mini-metric"><span>Loot bruto</span><strong>${compact(h.raw)}</strong></div><div class="mini-metric"><span>Supplies + extras</span><strong>${compact(h.supplies+h.extras)}</strong></div><div class="mini-metric"><span>Lucro ajustado</span><strong class="${h.profit>=0?"positive":"negative"}" title="${exact(h.profit)}">${compact(h.profit)}</strong></div></div>${state.page==="hunts"?'<p class="price-note">Resultado sem os recursos de profissão. O histórico mantém os valores completos da sessão.</p>':profitComparison(h)}${h.extras?`<p class="price-note">Gastos extras: ${exact(h.extras)}</p>`:""}${h.zero_prices?`<div class="notice">${icon("warning")}<span>${h.zero_prices} itens com preço zero nesta hunt.</span></div>`:""}${h.ghost_adjustment?`<p class="price-note">Giant Ghost · ${escapeHTML(h.ghost_adjustment.difficulty)}: ${h.ghost_adjustment.attempts} tentativas estimadas pelo consumo de ${h.ghost_adjustment.spell_tags} Spell Tags. ${h.ghost_adjustment.excluded} inimigos auxiliares descontados.</p>`:""}${defeatedPanel(h)}${capturesPanel([h])}<div class="section-heading"><h3>Drops, capturas e supplies</h3><span class="subtle">Valores usados nesta sessão</span></div><div class="review-table"><table><thead><tr><th>Item</th><th>Qtd.</th><th class="amount">Unitário</th><th class="amount">Total</th></tr></thead><tbody>${h.items.map(i=>`<tr class="${i.included?"":"disabled-row"}"><td class="item-name">${itemIdentity(i.name,`<small>${i.is_capture?"Captura":i.kind==="drop"?"Drop":"Supply"}${i.included?"":" · ignorado"}</small>`)}</td><td>${exact(i.count)}</td><td class="amount">${exact(i.price)}${i.reported_price!=null&&Math.abs(i.price-i.reported_price)>.009?`<small>JSON: ${exact(i.reported_price)}</small>`:""}</td><td class="amount">${exact(i.total)}</td></tr>`).join("")}</tbody></table></div>${h.notes?`<p class="detail-notes">${escapeHTML(h.notes)}</p>`:""}<div class="modal-actions"><button class="button ghost left" data-action="delete" data-id="${h.id}">${icon("trash")}Excluir</button><button class="button primary" data-action="edit" data-id="${h.id}">${icon("edit")}Editar hunt</button></div>`;
  $("#detail-dialog").showModal();
}
async function perform(action,button) {
  switch(action) {
    case "restore-backup":{
      if(!state.restoreBackup||!$("#restore-confirm")?.checked)throw new Error("Confira o backup e marque a confirmação para restaurar.");
      const result=await api("/api/restore",{backup:state.restoreBackup,confirmed:true});
      state.restoreBackup=null;state.restoreSummary=null;state.restoreName="";state.filter={};state.search="";
      $("#period").value="all";$("#location-filter").value="";$("#custom-dates").hidden=true;
      state.backupInfo=await api("/api/backup/info");await refresh();
      toast(`Backup restaurado: ${result.hunts} hunts e ${result.prices} preços. Cópia anterior disponível.`);break;
    }
    case "import":openImport();break;
    case "history":location.hash="history";break;
    case "sample":$("#json-input").value=JSON.stringify(await api("/api/sample"),null,2);$("#upload-title").textContent="Sua hunt de exemplo carregada";break;
    case "preview":try {const result=await api("/api/preview",{report:$("#json-input").value});review(result.record,result.exists,false,result.previous);}catch(e){importError(e.message);}break;
    case "back-import":openImport();break;
    case "save-hunt": {
      if(!categories[state.draft.category]){importError("Escolha a categoria: Hunt, Terror, Mystery Dungeon ou Mista.");$('[data-field="category"]').focus();return;}
      const fields=$$("input[type=number]",$("#import-dialog"));
      if(fields.some(e=>!e.checkValidity()||e.value==="")){importError("Preencha os preços e os gastos extras com números iguais ou maiores que zero.");return;}
      try {const updated=state.duplicate;await api("/api/hunts",{record:state.draft,replace:updated});$("#import-dialog").close();await refresh();toast(updated?"Hunt atualizada. Médias recalculadas.":"Hunt salva no seu histórico.");}catch(e){importError(e.message);}break;
    }
    case "detail":openDetail(button.dataset.id);break;
    case "edit":{const record=state.hunts.find(r=>r.id===button.dataset.id);$("#detail-dialog").close();review(record,true,true);break;}
    case "delete":state.pendingDelete=button.dataset.id;$("#delete-dialog").showModal();break;
    case "save-prices":
      if(state.prices.some(p=>!Number.isFinite(p.price)||p.price<0))throw new Error("Preencha os preços com números iguais ou maiores que zero.");
      document.querySelector("#price-confirm")?.remove();
      {const dialog=document.createElement("dialog");dialog.id="price-confirm";dialog.className="modal";
      dialog.innerHTML=`<div class="modal-head"><h2>Aplicar preços onde?</h2></div><p>Somente os itens com preços alterados serão atualizados. Aplicar ao histórico recalcula o lucro ajustado de todas as sessões que contêm esses itens, incluindo Hunts, Terrors e Mystery Dungeons. O lucro informado pelo jogo e os gastos extras serão preservados.</p><div class="modal-actions"><button class="text-button" id="price-cancel">Cancelar</button><button class="button ghost" data-price-scope="history">Histórico e futuras hunts</button><button class="button primary" data-price-scope="future">Somente futuras hunts</button></div>`;
      document.body.append(dialog);dialog.querySelector("#price-cancel").onclick=()=>dialog.close();
      dialog.querySelectorAll("[data-price-scope]").forEach(b=>b.onclick=async()=>{
        dialog.querySelectorAll("button").forEach(x=>x.disabled=true);
        try{const result=await api("/api/prices",{prices:state.prices,scope:b.dataset.priceScope});state.prices=await api("/api/prices");dialog.close();await refresh();renderPrices();toast(b.dataset.priceScope==="history"?`Preços salvos. ${result.updated_hunts} sessões atualizadas.`:"Preços salvos para próximas hunts. Histórico preservado.");}
        catch(e){toast(e.message,true);dialog.querySelectorAll("button").forEach(x=>x.disabled=false);}
      });dialog.showModal();}break;
  }
}
document.addEventListener("click",async event=>{
  const close=event.target.closest(".close-dialog");if(close){close.closest("dialog").close();return;}
  const nav=event.target.closest("[data-page]");if(nav){location.hash=nav.dataset.page;return;}
  const button=event.target.closest("[data-action]");if(!button)return;
  button.disabled=true;try{await perform(button.dataset.action,button);}catch(e){toast(e.message,true);}finally{button.disabled=false;}
});
$("#new-hunt").addEventListener("click",openImport);
$("#confirm-delete").addEventListener("click",async()=>{const b=$("#confirm-delete");b.disabled=true;try{await api("/api/delete",{id:state.pendingDelete});$("#delete-dialog").close();$("#detail-dialog").close();await refresh();toast("Hunt excluída.");}catch(e){toast(e.message,true);}finally{b.disabled=false;}});
async function applyFilters() {
  const period=$("#period").value;
  state.filter={};
  if(period==="custom"){
    const start=$("#date-start").value,end=$("#date-end").value;
    if(start&&end&&start>end){toast("A data inicial deve ser anterior à final.",true);return;}
    if(start)state.filter.start=start;if(end)state.filter.end=end;
  }else if(period!=="all"){
    const start=new Date(today()+"T12:00:00");start.setDate(start.getDate()-Number(period)+1);
    state.filter.start=`${start.getFullYear()}-${String(start.getMonth()+1).padStart(2,"0")}-${String(start.getDate()).padStart(2,"0")}`;state.filter.end=today();
  }
  if($("#location-filter").value)state.filter.location=$("#location-filter").value;
  try{await refresh();}catch(e){toast(e.message,true);}
}
$("#period").addEventListener("change",()=>{$("#custom-dates").hidden=$("#period").value!=="custom";if($("#period").value!=="custom")applyFilters();});
$("#apply-dates").addEventListener("click",applyFilters);$("#location-filter").addEventListener("change",applyFilters);
window.addEventListener("hashchange",()=>changePage(location.hash.slice(1)).catch(e=>toast(e.message,true)));
hydrateIcons();$("#date-end").value=today();$("#date-start").value=today().slice(0,8)+"01";
(async()=>{try{await refresh();await changePage(location.hash.slice(1));await openWeekly(1,true);}catch(e){$("#page-content").innerHTML=`<div class="empty"><h2>Não foi possível carregar o histórico.</h2><p>${escapeHTML(e.message)}</p><p>Verifique se o aplicativo local está aberto e atualize esta página.</p></div>`;}})();

document.addEventListener("click",event=>{
  const tab=event.target.closest("[data-battle-tab]");if(!tab)return;
  state.battleTab=tab.dataset.battleTab;
  tab.closest(".encounter-panel").outerHTML=defeatedPanel(state.stats,true);
  document.querySelector(`[data-battle-tab="${state.battleTab}"]`).focus({preventScroll:true});
});
document.addEventListener("keydown",event=>{
  if(!event.target.matches("[data-battle-tab]")||!["ArrowLeft","ArrowRight","Home","End"].includes(event.key))return;
  event.preventDefault();
  const tabs=["normal","rare","dungeon","boss"],index=tabs.indexOf(state.battleTab);
  const value=event.key==="Home"?tabs[0]:event.key==="End"?tabs.at(-1):tabs[(index+(event.key==="ArrowRight"?1:3))%4];
  document.querySelector(`[data-battle-tab="${value}"]`).click();
});

document.addEventListener("click",event=>{
  const card=event.target.closest("[data-pin-pokemon]");if(!card)return;
  const name=card.dataset.pinPokemon,key=battleKey(name);
  if(state.battlePins.has(key))state.battlePins.delete(key);else state.battlePins.add(key);
  try{localStorage.setItem("huntlog-battle-pins",JSON.stringify([...state.battlePins]));}catch{toast("Não foi possível guardar os fixados neste navegador.",true);}
  card.closest(".encounter-panel").outerHTML=defeatedPanel(state.stats,true);
  [...document.querySelectorAll("[data-pin-pokemon]")].find(e=>e.dataset.pinPokemon===name)?.focus({preventScroll:true});
});
document.addEventListener("input",event=>{
  if(event.target.id!=="battle-search")return;
  state.battleSearch[state.battleTab]=event.target.value;
  const template=document.createElement("template");template.innerHTML=defeatedPanel(state.stats,true);
  document.querySelector("#battle-results").replaceWith(template.content.querySelector("#battle-results"));
});

document.addEventListener("click",event=>{
 const editButton=event.target.closest("[data-edit-pokemon],#edit-pokemon-images");if(!editButton)return;
 $("#image-editor")?.remove();const dialog=document.createElement("dialog");dialog.id="image-editor";dialog.className="modal";
 dialog.innerHTML=`<div class="modal-head"><h2>Editar imagem do Pokémon</h2></div><div class="fields"><label class="field full">Pokémon<input id="image-name" list="image-pokemon-list" placeholder="Digite ou selecione o nome"><datalist id="image-pokemon-list">${(state.stats.defeated||[]).map(e=>`<option value="${escapeHTML(e.name)}"></option>`).join("")}</datalist></label><label class="field full">Link direto da imagem ou GIF<input id="image-url" type="url" placeholder="https://…"></label><label class="field full">Ou escolha um arquivo (até 2 MB)<input id="image-file" type="file" accept="image/png,image/jpeg,image/gif,image/webp"></label></div><img id="image-preview" alt="Prévia da imagem" hidden style="display:block;max-width:160px;max-height:160px;margin:16px auto"><p id="image-error" role="alert"></p><div class="modal-actions"><button class="text-button" id="image-close">Cancelar</button><button class="button ghost" id="image-reset">Restaurar padrão</button><button class="button primary" id="image-save">Salvar imagem</button></div>`;
 document.body.append(dialog);let value="",generation=0;
 const preview=()=>{const img=$("#image-preview");img.hidden=!value;if(value)img.src=value;else img.removeAttribute("src");};
 $("#image-name").onchange=()=>{generation++;value=state.customImages[imageKey($("#image-name").value)]||"";$("#image-url").value=value.startsWith("http")?value:"";$("#image-file").value="";preview();};
 $("#image-url").oninput=e=>{generation++;value=e.target.value.trim();$("#image-file").value="";if(/^https?:\/\//i.test(value))preview();};
 $("#image-file").onchange=async e=>{const file=e.target.files[0],token=++generation;if(!file)return;if(file.size>2000000){$("#image-error").textContent="Use um arquivo de até 2 MB.";return;}const reader=new FileReader();reader.onload=()=>{if(token!==generation)return;value=reader.result;$("#image-url").value="";$("#image-error").textContent="";preview();};reader.readAsDataURL(file);};
 $("#image-preview").onerror=()=>{$("#image-error").textContent="Não foi possível carregar a prévia. Confira o link ou arquivo.";};
 $("#image-close").onclick=()=>dialog.close();
 const save=async reset=>{try{if(!reset&&!value)throw new Error("Escolha um arquivo ou informe um link.");await api("/api/images",{name:$("#image-name").value,image:reset?"":value});await refresh();dialog.close();toast(reset?"Imagem padrão restaurada.":"Imagem salva.");}catch(e){$("#image-error").textContent=e.message;}};
 $("#image-save").onclick=()=>save(false);$("#image-reset").onclick=()=>save(true);if(editButton.dataset.editPokemon){$("#image-name").value=editButton.dataset.editPokemon;$("#image-name").onchange();}dialog.showModal();
});
function renderProfile(){
 const p=state.profile||{name:"Meu diário",characters:[],image:""};
 $("#player-name").textContent=p.name;
 const avatar=$(".profile .avatar");avatar.textContent=p.name.charAt(0).toUpperCase();
 if(p.image){const img=document.createElement("img");img.src=p.image;img.alt="Foto do perfil";img.onerror=()=>img.remove();avatar.append(img);}
 $(".profile small").textContent=p.characters.length?`${p.characters.length} personagens · Editar perfil`:"Editar meu perfil";
}
async function editProfile(){
 try{
 const p=await api("/api/profile");
 $("#profile-editor")?.remove();const dialog=document.createElement("dialog");dialog.id="profile-editor";dialog.className="modal";
 dialog.innerHTML=`<div class="modal-head"><h2>Meu perfil</h2><button class="icon-button close-dialog" aria-label="Fechar">${icon("close")}</button></div><p class="muted">Este nome fica fixo no seu diário. Cadastre aqui todos os seus chars e makers.</p><div class="fields"><label class="field full">Nome do perfil<input id="profile-name" maxlength="80" value="${escapeHTML(p.name)}"></label><label class="field full">Meus personagens / makers<textarea id="profile-characters" rows="6" placeholder="Um nome por linha">${escapeHTML(p.characters.join("\n"))}</textarea><small>Um nome por linha. Os logs continuam identificando o personagem de cada sessão.</small></label><button class="text-button" id="profile-import-chars">Adicionar nomes do histórico</button><label class="field full">Foto ou GIF (até 2 MB)<input type="file" id="profile-file" accept="image/png,image/jpeg,image/gif,image/webp"></label><label class="field full">Ou link direto da imagem<input type="url" id="profile-url" placeholder="https://…" value="${escapeHTML(p.image.startsWith("http")?p.image:"")}"></label></div><img id="profile-preview" alt="Prévia do perfil" style="width:88px;height:88px;object-fit:cover;border-radius:50%;margin:16px auto"><button class="text-button" id="profile-remove">Remover foto</button><p id="profile-error" role="alert"></p><div class="modal-actions"><button class="button close-dialog">Cancelar</button><button class="button primary" id="profile-save">Salvar perfil</button></div>`;
 document.body.append(dialog);let image=p.image,generation=0;
 const preview=()=>{const img=$("#profile-preview");img.hidden=!image;if(image)img.src=image;else img.removeAttribute("src");};preview();
 $("#profile-preview").onerror=()=>{$("#profile-error").textContent="Não foi possível carregar a foto. Confira o arquivo ou link.";};
 $("#profile-url").oninput=e=>{generation++;image=e.target.value.trim();$("#profile-file").value="";preview();};
 $("#profile-remove").onclick=()=>{generation++;image="";$("#profile-url").value="";$("#profile-file").value="";preview();};
 $("#profile-file").onchange=async e=>{const file=e.target.files[0],token=++generation;if(!file)return;try{if(file.size>2000000)throw new Error("Use uma foto de até 2 MB.");$("#profile-save").disabled=true;const result=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(new Error("Não foi possível ler o arquivo."));reader.readAsDataURL(file);});if(token===generation){image=result;$("#profile-url").value="";$("#profile-error").textContent="";preview();}}catch(e){$("#profile-error").textContent=e.message;}finally{$("#profile-save").disabled=false;}};
 $("#profile-import-chars").onclick=async()=>{try{const all=await api("/api/hunts"),names=new Map();[...$("#profile-characters").value.split("\n"),...all.hunts.map(h=>h.player)].forEach(n=>{n=n.trim();if(n)names.set(n.toLowerCase(),n);});$("#profile-characters").value=[...names.values()].join("\n");}catch(e){$("#profile-error").textContent=e.message;}};
 $("#profile-save").onclick=async()=>{const b=$("#profile-save");b.disabled=true;try{state.profile=await api("/api/profile",{name:$("#profile-name").value,characters:$("#profile-characters").value.split("\n"),image});renderProfile();dialog.close();toast("Perfil salvo.");}catch(e){$("#profile-error").textContent=e.message;}finally{b.disabled=false;}};
 dialog.showModal();
 }catch(e){toast(e.message,true);}
}
$(".profile").addEventListener("click",editProfile);
$(".profile").addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();editProfile();}});
let weeklyRequest=0;
async function openWeekly(weeks=1,automatic=false){
 const request=++weeklyRequest;
 try{
 const data=await api('/api/weekly?weeks_ago='+weeks);if(request!==weeklyRequest)return;
 if(automatic&&!data.stats.count)return;
 let dialog=$('#weekly-dialog');if(!dialog){dialog=document.createElement('dialog');dialog.id='weekly-dialog';dialog.className='modal detail-modal';document.body.append(dialog);}
 const s=data.stats,top=data.contents[0],most=data.defeated[0];
 const date=value=>new Intl.DateTimeFormat('pt-BR',{timeZone:'America/Sao_Paulo',day:'2-digit',month:'2-digit',year:'numeric'}).format(new Date(value));
 const list=(title,rows)=>`<section class="panel weekly-list"><h3>${title} <span class="subtle">(${exact(rows.reduce((n,r)=>n+r.count,0))})</span></h3>${rows.length?`<div class="table-wrap"><table><thead><tr><th>Pokémon</th><th class="amount">Quantidade</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${itemIdentity(r.name,'',true)}</td><td class="amount">${exact(r.count)}</td></tr>`).join('')}</tbody></table></div>`:'<p class="muted">Nenhum registrado nesta semana.</p>'}</section>`;
 dialog.innerHTML=`<div class="modal-head"><div><p class="eyebrow">SEU DIÁRIO DA SEMANA</p><h2>Resumo semanal${weeks===0?' · Em andamento':''}</h2></div><button class="icon-button close-dialog" aria-label="Fechar">${icon('close')}</button></div><p>${date(data.start)} às 07h45 até ${date(data.end)} às 07h45 · Brasília</p><div class="weekly-controls"><button class="button ghost small" id="weekly-older" ${weeks>=520?'disabled':''}>← Semana anterior</button><button class="button ghost small" id="weekly-newer" ${weeks===0?'disabled':''}>Semana seguinte →</button><button class="text-button" id="weekly-current">Semana atual</button></div><p class="muted">${s.count} sessões · ${duration(s.duration)} · Todos os seus personagens</p>${!s.count?'<p class="notice">Não há sessões registradas neste período.</p>':''}<div class="mini-metrics"><div class="mini-metric"><span>Cash total feito · lucro líquido ajustado</span><strong class="${s.profit<0?'negative':'positive'}">${exact(s.profit)}</strong><small>Loot ${exact(s.raw)} − gastos ${exact(s.cost)}</small></div><div class="mini-metric"><span>Conteúdo mais lucrativo · total</span><strong>${top?escapeHTML(top.name):'—'}</strong><small>${top?`${categories[top.category]} · ${exact(top.profit)} · ${top.count} sessões`:''}</small></div><div class="mini-metric"><span>Pokémon mais derrotado</span><strong>${most?escapeHTML(most.name):'—'}</strong><small>${most?`${exact(most.count)} derrotados`:''}</small></div></div>${s.tracked_hunts<s.count?'<p class="muted">Algumas sessões não têm registro de Pokémon derrotados.</p>':''}<div class="weekly-lists">${list('Pokémon raros derrotados',data.rares)}${list('Pokémon capturados',data.captures)}</div><p class="price-note">Sessões agrupadas pelo horário de início. Uma sessão que atravessa o reset fica na semana em que começou. O conteúdo mais lucrativo considera o lucro total por categoria e local.</p><div class="modal-actions"><button class="button ghost" id="weekly-copy">Copiar imagem</button><button class="button ghost" id="weekly-download">Baixar PNG</button><button class="button primary close-dialog">Fechar resumo</button></div>`;
 $('#weekly-copy').onclick=()=>shareWeekly(false);$('#weekly-download').onclick=()=>shareWeekly(true);
 $('#weekly-older').onclick=()=>openWeekly(weeks+1);$('#weekly-newer').onclick=()=>openWeekly(weeks-1);$('#weekly-current').onclick=()=>openWeekly(0);
 if(!dialog.open)dialog.showModal();
 }catch(e){toast('Não foi possível carregar o resumo semanal: '+e.message,true);}
}
$('#weekly-summary').addEventListener('click',()=>openWeekly());
async function weeklyImageBlob(){
 const source=$('#weekly-dialog');if(!source)throw new Error('Abra o resumo semanal primeiro.');
 const copy=document.createElement('div');copy.id='weekly-export';copy.className='modal detail-modal';copy.innerHTML=source.innerHTML;
 copy.querySelectorAll('.weekly-controls,.modal-actions,.close-dialog').forEach(e=>e.remove());
 Object.assign(copy.style,{position:'absolute',left:'0',top:window.scrollY+'px',width:'1000px',maxWidth:'none',height:'auto',maxHeight:'none',overflow:'visible',margin:'0',zIndex:'-100',boxShadow:'none'});
 copy.querySelectorAll('.table-wrap').forEach(e=>{e.style.overflow='visible';});
 copy.querySelectorAll('img').forEach(img=>{img.loading='eager';img.removeAttribute('onload');img.removeAttribute('onerror');});
 document.body.append(copy);
 try{
 await document.fonts.ready;
 await Promise.all([...copy.querySelectorAll('img')].map(async img=>{try{await Promise.race([img.decode(),new Promise((_,reject)=>setTimeout(()=>reject(new Error('timeout')),12000))]);img.parentElement.classList.add('loaded');}catch{img.remove();}}));
 const canvas=await html2canvas(copy,{backgroundColor:'#101827',scale:1.5,useCORS:true,logging:false,windowWidth:1200,windowHeight:copy.scrollHeight+100,height:copy.scrollHeight});
 return await new Promise((resolve,reject)=>canvas.toBlob(blob=>blob?resolve(blob):reject(new Error('Não foi possível gerar a imagem.')),'image/png'));
 }finally{copy.remove();}
}
async function shareWeekly(download){
 const buttons=[$('#weekly-copy'),$('#weekly-download')];buttons.forEach(b=>b.disabled=true);
 const save=blob=>{const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='huntlog-resumo-semanal.png';a.click();setTimeout(()=>URL.revokeObjectURL(url),60000);};
 try{
 const pending=weeklyImageBlob();
 if(!download&&navigator.clipboard?.write&&window.ClipboardItem){
  try{await navigator.clipboard.write([new ClipboardItem({'image/png':pending})]);toast('Imagem copiada! Use Ctrl + V para colar.');}
  catch(error){save(await pending);toast('Não foi possível copiar. A imagem foi baixada em PNG.');}
 }else{save(await pending);toast(download?'Resumo salvo em PNG.':'Cópia indisponível neste navegador. PNG baixado.');}
 }catch(e){toast(e.message,true);}finally{buttons.forEach(b=>b.disabled=false);}
}
